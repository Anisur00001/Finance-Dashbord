import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Wallet, Plus, ArrowUpRight, ArrowDownRight, LogOut, Bitcoin, DollarSign, Menu, X } from 'lucide-react';
import BottomSheet from '../components/BottomSheet';
import AddTransactionForm from '../components/AddTransactionForm';

export default function Dashboard() {
  const { signOut, user, supabase } = useAuth();
  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
  const [transactionType, setTransactionType] = useState<'expense' | 'income'>('expense');
  const [transactions, setTransactions] = useState<any[]>([]);
  const [accountData, setAccountData] = useState({
    totalBalance: 9453.89,
    monthlyIncome: 4500.00,
    monthlyExpenses: 2845.50,
    cryptoHoldings: 3254.75
  });
  const [isLoading, setIsLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (supabase && user) {
      fetchTransactions();
      fetchAccountData();
    }
  }, [supabase, user]);

  const fetchAccountData = async () => {
    if (!supabase || !user) return;

    try {
      // Fetch account balances
      const { data: accounts, error: accountsError } = await supabase
        .from('accounts')
        .select('*')
        .eq('user_id', user.id);

      if (accountsError) {
        console.error('Error fetching accounts:', accountsError);
        return;
      }

      // Calculate total balance from all accounts
      const totalBalance = accounts?.reduce((sum, account) => sum + (account.balance || 0), 0) || 9453.89;

      // Fetch monthly income (current month)
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data: incomeData, error: incomeError } = await supabase
        .from('transactions')
        .select('amount')
        .eq('user_id', user.id)
        .eq('type', 'income')
        .gte('date', startOfMonth.toISOString());

      if (incomeError) {
        console.error('Error fetching income:', incomeError);
      }

      // Calculate monthly income
      const monthlyIncome = incomeData?.reduce((sum, transaction) => sum + Math.abs(transaction.amount || 0), 0) || 4500.00;

      // Fetch monthly expenses (current month)
      const { data: expenseData, error: expenseError } = await supabase
        .from('transactions')
        .select('amount')
        .eq('user_id', user.id)
        .eq('type', 'expense')
        .gte('date', startOfMonth.toISOString());

      if (expenseError) {
        console.error('Error fetching expenses:', expenseError);
      }

      // Calculate monthly expenses
      const monthlyExpenses = expenseData?.reduce((sum, transaction) => sum + Math.abs(transaction.amount || 0), 0) || 2845.50;

      setAccountData({
        totalBalance,
        monthlyIncome,
        monthlyExpenses,
        cryptoHoldings: 3254.75 // Static for now
      });
    } catch (error) {
      console.error('Error fetching account data:', error);
    }
  };

  const fetchTransactions = async () => {
    if (!supabase || !user) return;

    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('transactions')
        .select(`
          *,
          categories:category_id(name, type)
        `)
        .eq('user_id', user.id)
        .order('date', { ascending: false })
        .limit(5);

      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddTransaction = (type: 'expense' | 'income') => {
    setTransactionType(type);
    setIsBottomSheetOpen(true);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const getTransactionIcon = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'grocery store':
      case 'food':
        return <div className="bg-red-100 p-2 rounded-full"><DollarSign className="h-4 w-4 text-red-500" /></div>;
      case 'salary':
      case 'monthly salary':
        return <div className="bg-green-100 p-2 rounded-full"><DollarSign className="h-4 w-4 text-green-500" /></div>;
      case 'netflix subscription':
      case 'entertainment':
        return <div className="bg-red-100 p-2 rounded-full"><DollarSign className="h-4 w-4 text-red-500" /></div>;
      case 'coffee shop':
      case 'coffee':
        return <div className="bg-red-100 p-2 rounded-full"><DollarSign className="h-4 w-4 text-red-500" /></div>;
      default:
        return <div className="bg-gray-100 p-2 rounded-full"><DollarSign className="h-4 w-4 text-gray-500" /></div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Wallet className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-semibold">FinanceTracker</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center">
              <span className="mr-4 text-sm truncate max-w-[200px]">{user?.email}</span>
              <button
                onClick={() => signOut()}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </button>
            </div>
            
            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
              >
                {mobileMenuOpen ? (
                  <X className="block h-6 w-6" />
                ) : (
                  <Menu className="block h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <div className="px-3 py-2 text-sm text-gray-700 truncate">
                {user?.email}
              </div>
              <button
                onClick={() => signOut()}
                className="w-full text-left block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
              >
                Sign Out
              </button>
            </div>
          </div>
        )}
      </nav>

      <main className="max-w-7xl mx-auto py-4 px-4 sm:py-6 sm:px-6 lg:px-8">
        {/* Financial Overview */}
        <div className="mb-6 sm:mb-8">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-1">Financial Overview</h2>
          <p className="text-xs sm:text-sm text-gray-500 mb-3 sm:mb-4">Track your spending and saving progress</p>
          
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-4 sm:gap-4">
            {/* Total Balance */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <p className="text-xs sm:text-sm text-gray-500 mb-1">Total Balance</p>
              <p className="text-base sm:text-xl font-bold">{formatCurrency(accountData.totalBalance)}</p>
              <div className="flex items-center mt-1">
                <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                <span className="text-xs text-green-500">+2.5% vs last month</span>
              </div>
            </div>
            
            {/* Monthly Income */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <p className="text-xs sm:text-sm text-gray-500 mb-1">Monthly Income</p>
              <p className="text-base sm:text-xl font-bold">{formatCurrency(accountData.monthlyIncome)}</p>
              <div className="flex items-center mt-1">
                <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                <span className="text-xs text-green-500">+1.2% vs last month</span>
              </div>
            </div>
            
            {/* Monthly Expenses */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <p className="text-xs sm:text-sm text-gray-500 mb-1">Monthly Expenses</p>
              <p className="text-base sm:text-xl font-bold">{formatCurrency(accountData.monthlyExpenses)}</p>
              <div className="flex items-center mt-1">
                <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                <span className="text-xs text-red-500">+0.8% vs last month</span>
              </div>
            </div>
            
            {/* Crypto Holdings */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <p className="text-xs sm:text-sm text-gray-500 mb-1">Crypto Holdings</p>
              <p className="text-base sm:text-xl font-bold">{formatCurrency(accountData.cryptoHoldings)}</p>
              <div className="flex items-center mt-1">
                <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                <span className="text-xs text-green-500">+5.2% vs last month</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Budget Overview */}
        <div className="mb-6 sm:mb-8">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">Budget Overview</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 sm:gap-4">
            {/* Shopping */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <div className="bg-purple-100 p-1.5 sm:p-2 rounded-full mr-2">
                    <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-purple-500" />
                  </div>
                  <span className="text-sm sm:text-base font-medium">Shopping</span>
                </div>
                <span className="text-xs text-gray-500">$350 / $500</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{ width: '70%' }}></div>
              </div>
            </div>
            
            {/* Dining */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <div className="bg-blue-100 p-1.5 sm:p-2 rounded-full mr-2">
                    <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-blue-500" />
                  </div>
                  <span className="text-sm sm:text-base font-medium">Dining</span>
                </div>
                <span className="text-xs text-gray-500">$150 / $300</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '50%' }}></div>
              </div>
            </div>
            
            {/* Coffee */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <div className="bg-yellow-100 p-1.5 sm:p-2 rounded-full mr-2">
                    <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-yellow-500" />
                  </div>
                  <span className="text-sm sm:text-base font-medium">Coffee</span>
                </div>
                <span className="text-xs text-gray-500">$50 / $80</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '62.5%' }}></div>
              </div>
            </div>
            
            {/* Bills */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <div className="bg-indigo-100 p-1.5 sm:p-2 rounded-full mr-2">
                    <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-indigo-500" />
                  </div>
                  <span className="text-sm sm:text-base font-medium">Bills</span>
                </div>
                <span className="text-xs text-gray-500">$1,000 / $1,500</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-indigo-500 h-2 rounded-full" style={{ width: '66.7%' }}></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Crypto Portfolio */}
        <div className="mb-6 sm:mb-8">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">Crypto Portfolio</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 sm:gap-4">
            {/* Bitcoin */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-1">
                <div className="flex items-center">
                  <Bitcoin className="h-4 w-4 sm:h-5 sm:w-5 text-orange-500 mr-2" />
                  <span className="text-sm sm:text-base font-medium">Bitcoin</span>
                </div>
                <span className="text-xs text-gray-500">BTC</span>
              </div>
              <p className="text-base sm:text-lg font-bold mb-1">$2500.00</p>
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">Amount: 0.1 BTC</span>
                <span className="text-xs text-green-500">+1.2%</span>
              </div>
            </div>
            
            {/* Ethereum */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-1">
                <div className="flex items-center">
                  <div className="h-4 w-4 sm:h-5 sm:w-5 text-purple-500 mr-2">Ξ</div>
                  <span className="text-sm sm:text-base font-medium">Ethereum</span>
                </div>
                <span className="text-xs text-gray-500">ETH</span>
              </div>
              <p className="text-base sm:text-lg font-bold mb-1">$625.75</p>
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">Amount: 0.5 ETH</span>
                <span className="text-xs text-green-500">+3.7%</span>
              </div>
            </div>
            
            {/* Solana */}
            <div className="bg-white p-3 sm:p-4 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-1">
                <div className="flex items-center">
                  <div className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500 mr-2">◎</div>
                  <span className="text-sm sm:text-base font-medium">Solana</span>
                </div>
                <span className="text-xs text-gray-500">SOL</span>
              </div>
              <p className="text-base sm:text-lg font-bold mb-1">$129.00</p>
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">Amount: 10 SOL</span>
                <span className="text-xs text-green-500">+6.9%</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Recent Transactions */}
        <div className="pb-20 sm:pb-0">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">Recent Transactions</h2>
          <div className="bg-white rounded-lg shadow-sm divide-y">
            {isLoading ? (
              <div className="p-4 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-2 text-gray-500">Loading transactions...</p>
              </div>
            ) : transactions.length > 0 ? (
              transactions.map((transaction) => (
                <div key={transaction.id} className="p-3 sm:p-4 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="bg-opacity-20 p-1.5 sm:p-2 rounded-full mr-2 sm:mr-3" 
                         style={{ backgroundColor: transaction.type === 'income' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)' }}>
                      <DollarSign className="h-3 w-3 sm:h-4 sm:w-4" 
                                 style={{ color: transaction.type === 'income' ? 'rgb(16, 185, 129)' : 'rgb(239, 68, 68)' }} />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-medium truncate max-w-[120px] sm:max-w-none">{transaction.description}</p>
                      <p className="text-xs text-gray-500">{transaction.categories?.name || 'Uncategorized'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm sm:text-base font-medium" 
                       style={{ color: transaction.type === 'income' ? 'rgb(16, 185, 129)' : 'rgb(239, 68, 68)' }}>
                      {transaction.type === 'income' ? '+' : '-'}{formatCurrency(Math.abs(transaction.amount))}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(transaction.date).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-gray-500">
                No recent transactions found
              </div>
            )}
            
            {/* Fallback static transactions if no real data */}
            {!isLoading && transactions.length === 0 && (
              <>
                {/* Transaction 1 */}
                <div className="p-3 sm:p-4 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="bg-red-100 p-1.5 sm:p-2 rounded-full mr-2 sm:mr-3">
                      <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-red-500" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-medium">Grocery Store</p>
                      <p className="text-xs text-gray-500">Food</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm sm:text-base font-medium text-red-500">-$45.50</p>
                    <p className="text-xs text-gray-500">Today, 10:00 AM</p>
                  </div>
                </div>
                
                {/* Transaction 2 */}
                <div className="p-3 sm:p-4 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="bg-green-100 p-1.5 sm:p-2 rounded-full mr-2 sm:mr-3">
                      <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-green-500" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-medium">Monthly Salary</p>
                      <p className="text-xs text-gray-500">Salary</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm sm:text-base font-medium text-green-500">+$4500.00</p>
                    <p className="text-xs text-gray-500">Yesterday</p>
                  </div>
                </div>
                
                {/* Transaction 3 */}
                <div className="p-3 sm:p-4 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="bg-red-100 p-1.5 sm:p-2 rounded-full mr-2 sm:mr-3">
                      <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-red-500" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-medium">Netflix Subscription</p>
                      <p className="text-xs text-gray-500">Entertainment</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm sm:text-base font-medium text-red-500">-$18.99</p>
                    <p className="text-xs text-gray-500">May 15</p>
                  </div>
                </div>
                
                {/* Transaction 4 */}
                <div className="p-3 sm:p-4 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="bg-red-100 p-1.5 sm:p-2 rounded-full mr-2 sm:mr-3">
                      <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-red-500" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-medium">Coffee Shop</p>
                      <p className="text-xs text-gray-500">Food</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm sm:text-base font-medium text-red-500">-$5.00</p>
                    <p className="text-xs text-gray-500">May 14</p>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
        
        {/* Transaction Buttons - Mobile */}
        <div className="fixed bottom-6 right-6 flex space-x-4 z-10 sm:hidden">
          <button
            onClick={() => handleAddTransaction('expense')}
            className="flex items-center justify-center p-3 bg-red-600 text-white rounded-full shadow-lg hover:bg-red-700 transition-colors"
            aria-label="Add expense"
          >
            <Plus className="h-6 w-6" />
          </button>
          <button
            onClick={() => handleAddTransaction('income')}
            className="flex items-center justify-center p-3 bg-green-600 text-white rounded-full shadow-lg hover:bg-green-700 transition-colors"
            aria-label="Add income"
          >
            <Plus className="h-6 w-6" />
          </button>
        </div>
        
        {/* Transaction Buttons - Desktop */}
        <div className="hidden sm:flex mt-8 space-x-4">
          <button
            onClick={() => handleAddTransaction('expense')}
            className="flex-1 inline-flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md text-white bg-red-600 hover:bg-red-700 shadow-sm transition-colors"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Expense
          </button>
          <button
            onClick={() => handleAddTransaction('income')}
            className="flex-1 inline-flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700 shadow-sm transition-colors"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Income
          </button>
        </div>
      </main>

      {/* Bottom Sheet */}
      <BottomSheet
        isOpen={isBottomSheetOpen}
        onClose={() => setIsBottomSheetOpen(false)}
      >
        <AddTransactionForm
          type={transactionType}
          onClose={() => {
            setIsBottomSheetOpen(false);
            fetchTransactions();
            fetchAccountData(); // Refresh account data after adding a transaction
          }}
        />
      </BottomSheet>
    </div>
  );
}