/*
  # Add update_account_balance function

  1. New Functions
    - `update_account_balance`: Updates an account's balance when a transaction is added
      - Parameters:
        - `p_account_id`: The account ID to update
        - `p_amount`: The amount to add to the balance (negative for expenses)

  2. Security
    - Function is set to SECURITY DEFINER to run with elevated privileges
    - Access is restricted through RLS policies on the accounts table
*/

CREATE OR REPLACE FUNCTION update_account_balance(p_account_id uuid, p_amount decimal)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE accounts
  SET balance = balance + p_amount,
      updated_at = now()
  WHERE id = p_account_id;
END;
$$;