import React, { useEffect } from 'react';

interface BottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

export default function BottomSheet({ isOpen, onClose, children }: BottomSheetProps) {
  // Prevent body scrolling when bottom sheet is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <>
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 transition-opacity z-40"
        onClick={onClose}
        aria-hidden="true"
      />
      <div 
        className="fixed inset-x-0 bottom-0 transform transition-transform z-50 bg-white rounded-t-2xl shadow-lg max-h-[90vh] overflow-y-auto"
        role="dialog"
        aria-modal="true"
      >
        <div className="w-full p-4 sm:p-6 max-w-lg mx-auto">
          <div className="mx-auto w-12 h-1.5 bg-gray-300 rounded-full mb-4" />
          {children}
        </div>
      </div>
    </>
  );
}